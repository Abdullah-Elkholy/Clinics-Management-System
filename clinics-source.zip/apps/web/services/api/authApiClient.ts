import type { User } from '@/types';
/**
 * Authentication API Client
 * Handles login and authentication-related API calls
 */

export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  success: boolean;
  data?: {
    accessToken: string;
  };
  errors?: Array<{
    code: string;
    message: string;
  }>;
}

export class ApiError extends Error {
  statusCode: number;
  details?: unknown;
  constructor(message: string, statusCode: number, details?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.statusCode = statusCode;
    this.details = details;
    // Ensure instanceof works
    Object.setPrototypeOf(this, ApiError.prototype);
  }
  toJSON() {
    return { name: this.name, message: this.message, statusCode: this.statusCode, details: this.details };
  }
}

// ============================================
// API Client Configuration
// ============================================

const getApiBaseUrl = (): string => {
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';
  // Ensure /api is appended if not already present
  return baseUrl.endsWith('/api') ? baseUrl : `${baseUrl}/api`;
};

// ============================================
// Authentication API
// ============================================

/**
 * Login with username and password
 * Returns JWT access token to be stored in localStorage
 */
export async function login(credentials: LoginRequest): Promise<LoginResponse> {
  const API_BASE_URL = getApiBaseUrl();
  const url = `${API_BASE_URL}/auth/login`;

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(credentials),
    });

    let data: unknown;
    const contentType = response.headers.get('content-type');
    if (contentType?.includes('application/json')) {
      data = await response.json();
    } else {
      data = await response.text();
    }

    if (!response.ok) {
      const message = (typeof data === 'string' ? data : ((data as Record<string, unknown>)?.errors as Array<{message: string}>)?.[0]?.message || (data as Record<string, unknown>)?.message as string) || response.statusText || 'Login failed';
      // Don't trigger global auth handler for login endpoint - these are expected errors
      throw new ApiError(message, response.status, typeof data === 'string' ? { raw: data } : data);
    }

    return data as LoginResponse;
  } catch (error) {
    // Handle network errors (fetch failures)
    if (error instanceof ApiError) {
      throw error; // Re-throw our ApiError as-is
    }
    // Network error from fetch (TypeError: Failed to fetch)
    throw new ApiError('تعذر الاتصال بالخادم. تأكد من أن الخادم يعمل وحاول مرة أخرى', 0);
  }
}

/**
 * Get current authenticated user information
 */
export async function getCurrentUser(): Promise<User> {
  const API_BASE_URL = getApiBaseUrl();
  const url = `${API_BASE_URL}/auth/me`;
  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  try {
    const response = await fetch(url, {
      headers,
    });

    let data: unknown;
    const contentType = response.headers.get('content-type');
    if (contentType?.includes('application/json')) {
      data = await response.json();
    } else {
      data = await response.text();
    }

    if (!response.ok) {
      const message = (typeof data === 'string' ? data : (data as Record<string, unknown>)?.message as string) || response.statusText || 'فشل تحميل بيانات المستخدم الحالي';
      const error = new ApiError(message, response.status, typeof data === 'string' ? { raw: data } : data);
      
      // Handle auth errors globally, but only if this is NOT a user data refresh after login
      // We check this by seeing if we have a token - if we do, it might be a refresh issue, not auth failure
      // Only trigger logout if we're certain it's an auth failure (no token or token is definitely invalid)
      if (response.status === 401 || response.status === 403) {
        const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
        // Only trigger global logout if we don't have a token
        // If we have a token but get 401, it might be a temporary issue or token refresh needed
        // Let the caller handle it (they might want to retry or use cached user data)
        if (!token) {
          const { handleApiError } = require('@/utils/apiInterceptor');
          handleApiError({ statusCode: response.status, message });
        } else {
          // We have a token but got 401/403 - log but don't trigger logout
          // This might be a temporary issue or the token needs refresh
          if (process.env.NODE_ENV === 'development') {
            console.warn('[getCurrentUser] Got 401/403 but token exists - might be temporary or need refresh');
          }
        }
      }
      
      throw error;
    }

    // Backend returns { success: true, data: { Id, Username, FirstName, LastName, Role, ... } }
    // Need to unwrap and convert PascalCase to camelCase
    const responseData = data as { success: boolean; data: any };
    if (responseData.success && responseData.data) {
      const userData = responseData.data;
      
      // Debug log in development
      if (process.env.NODE_ENV === 'development') {
        console.log('[getCurrentUser] Backend response data:', userData);
        console.log('[getCurrentUser] Role value:', userData.Role || userData.role);
      }
      
      // Backend only returns minimal fields from /auth/me endpoint
      // Provide sensible defaults for required User interface fields
      const user = {
        id: String(userData.Id || userData.id || ''),
        username: userData.Username || userData.username || '',
        firstName: userData.FirstName || userData.firstName || '',
        lastName: userData.LastName || userData.lastName || '',
        role: userData.Role || userData.role,
        // Fields not returned by backend - use sensible defaults
        isActive: true, // User must be active to be authenticated
        createdAt: new Date(),
        updatedAt: new Date(),
        // Optional fields
        lastLogin: undefined,
        assignedModerator: userData.AssignedModerator || userData.assignedModerator || userData.ModeratorId || userData.moderatorId,
        moderatorQuota: userData.ModeratorQuota || userData.moderatorQuota,
        createdBy: undefined,
        isDeleted: false,
        deletedAt: undefined,
      } as User;
      
      if (process.env.NODE_ENV === 'development') {
        console.log('[getCurrentUser] Mapped user object:', user);
      }
      
      return user;
    }

    // Fallback: try to use data directly (shouldn't happen with current backend)
    return data as User;
  } catch (error) {
    // Handle network errors (fetch failures)
    if (error instanceof ApiError) {
      throw error; // Re-throw our ApiError as-is
    }
    // Network error from fetch (TypeError: Failed to fetch)
    throw new ApiError('تعذر الاتصال بالخادم. تأكد من أن الخادم يعمل وحاول مرة أخرى', 0);
  }
}

/**
 * Logout by clearing token and revoking refresh token session on backend
 */
export async function logout(): Promise<void> {
  if (typeof window !== 'undefined') {
    // Clear token from localStorage first
    localStorage.removeItem('token');
    
    // Call backend to revoke refresh token session
    try {
      const API_BASE_URL = getApiBaseUrl();
      const url = `${API_BASE_URL}/auth/logout`;
      
      await fetch(url, {
        method: 'POST',
        credentials: 'include', // Include HttpOnly refresh token cookie
        headers: {
          'Content-Type': 'application/json',
        },
      });
      // Ignore response - logout should succeed even if backend call fails
    } catch (error) {
      // Ignore errors - logout is best-effort on backend
      // Client-side cleanup is most important
    }
  }
}

// ============================================
// Token Refresh API
// ============================================

/**
 * Attempt to refresh the access token using the HttpOnly refresh cookie.
 * Returns the new access token on success, or null on failure.
 */
export async function refreshAccessToken(): Promise<{ accessToken: string } | null> {
  const API_BASE_URL = getApiBaseUrl();
  const url = `${API_BASE_URL}/auth/refresh`;

  try {
    const response = await fetch(url, {
      method: 'POST',
      credentials: 'include', // Include HttpOnly refresh token cookie
      headers: { 'Content-Type': 'application/json' },
    });

    const contentType = response.headers.get('content-type') || '';
    const data = contentType.includes('application/json') ? await response.json() : await response.text();

    if (!response.ok) {
      // Log 401 errors for debugging (refresh token expired/missing is expected in some cases)
      if (response.status === 401) {
        console.debug('[Auth] Refresh token request returned 401 - token may be expired or missing');
      } else {
        console.warn('[Auth] Refresh token request failed with status:', response.status);
      }
      return null;
    }

    // Expected: { success: true, data: { accessToken, expiresIn } }
    const token = (data && (data as any).data && (data as any).data.accessToken) as string | undefined;
    if (token && typeof token === 'string') {
      return { accessToken: token };
    }
    return null;
  } catch (error) {
    console.debug('[Auth] Refresh token request failed:', error);
    return null;
  }
}
