'use client';

import ProtectedRoute from '../../components/Auth/ProtectedRoute';
import MainApp from '../../components/MainApp/MainApp';

export default function MessagesPage() {
  return (
    <ProtectedRoute>
      <MainApp />
    </ProtectedRoute>
  );
}

