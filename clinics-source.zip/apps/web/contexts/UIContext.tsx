'use client';

import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import type { Toast } from '../types';

interface UIContextType {
  toasts: Toast[];
  addToast: (message: string, type: 'success' | 'error' | 'info' | 'warning', debugData?: Record<string, any>) => void;
  removeToast: (id: string) => void;
  currentPanel: 'messages' | 'management' | 'welcome' | 'ongoing' | 'failed' | 'completed';
  setCurrentPanel: (panel: 'messages' | 'management' | 'welcome' | 'ongoing' | 'failed' | 'completed') => void;
  selectedQueueId: string | null;
  setSelectedQueueId: (id: string | null) => void;
  isTransitioning: boolean;
}

const UIContext = createContext<UIContextType | null>(null);

export const UIProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const pathname = usePathname();
  const router = useRouter();
  const [toasts, setToasts] = useState<Toast[]>([]);
  // Initialize selectedQueueId from localStorage synchronously to prevent race conditions
  const [selectedQueueId, setSelectedQueueId] = useState<string | null>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('selectedQueueId');
      return stored || null;
    }
    return null;
  });
  const [currentPanel, setCurrentPanel] = useState<'messages' | 'management' | 'welcome' | 'ongoing' | 'failed' | 'completed'>('welcome');
  const [isTransitioning, setIsTransitioning] = useState(false);
  const toastCounterRef = React.useRef(0);
  const transitionTimeoutRef = React.useRef<NodeJS.Timeout | null>(null);
  const navigationTimeoutRef = React.useRef<NodeJS.Timeout | null>(null);
  const pendingPanelRef = React.useRef<'messages' | 'management' | 'welcome' | 'ongoing' | 'failed' | 'completed' | null>(null);

  // Sync selectedQueueId with localStorage on mount (if not already set from initial state)
  // This ensures queue is available immediately when queue routes are accessed
  useEffect(() => {
    if (!selectedQueueId && typeof window !== 'undefined') {
      const stored = localStorage.getItem('selectedQueueId');
      if (stored) {
        setSelectedQueueId(stored);
      }
    }
  }, []); // Only run once on mount

  // Persist selectedQueueId to localStorage whenever it changes
  useEffect(() => {
    if (selectedQueueId) {
      localStorage.setItem('selectedQueueId', selectedQueueId);
    } else {
      localStorage.removeItem('selectedQueueId');
    }
  }, [selectedQueueId]);

  // Sync state with URL on mount and pathname changes
  // Use ref to prevent infinite loops when state updates trigger URL changes
  const isUpdatingFromUrl = React.useRef(false);
  const lastPathnameRef = React.useRef<string | null>(null);
  const isNavigatingProgrammatically = React.useRef(false);

  // Helper function to get path for a panel (defined before useEffect that uses it)
  const getPathForPanel = React.useCallback((panel: 'messages' | 'management' | 'welcome' | 'ongoing' | 'failed' | 'completed'): string => {
    switch (panel) {
      case 'messages':
        return '/messages';
      case 'management':
        return '/management';
      case 'welcome':
        return '/queues/dashboard';
      case 'ongoing':
        return '/queues/ongoing';
      case 'failed':
        return '/queues/failed';
      case 'completed':
        return '/queues/completed';
      default:
        return '/home';
    }
  }, []);

  useEffect(() => {
    // Skip if already updating or pathname hasn't changed
    // Also skip if we're in the middle of programmatic navigation
    if (!pathname || lastPathnameRef.current === pathname) {
      // If we have a pending panel and URL matches, activate it
      if (pendingPanelRef.current && !isUpdatingFromUrl.current && !isNavigatingProgrammatically.current) {
        const targetPath = getPathForPanel(pendingPanelRef.current);
        if (pathname === targetPath) {
          setCurrentPanel(pendingPanelRef.current);
          pendingPanelRef.current = null;
          setIsTransitioning(false);
        }
      }
      return;
    }

    // If we're navigating programmatically, let the navigation handler manage state
    if (isNavigatingProgrammatically.current) {
      lastPathnameRef.current = pathname;
      // Check if URL matches pending panel
      if (pendingPanelRef.current) {
        const targetPath = getPathForPanel(pendingPanelRef.current);
        if (pathname === targetPath) {
          // URL matches pending panel - activate it immediately
          setCurrentPanel(pendingPanelRef.current);
          pendingPanelRef.current = null;
          setIsTransitioning(false);
          // Reset flags
          isNavigatingProgrammatically.current = false;
          isUpdatingFromUrl.current = false;
          // Don't return - let the URL sync continue to ensure queue selection is handled
        } else {
          // URL doesn't match pending panel - this might be browser navigation
          // Clear pending panel and let normal URL sync handle it
          pendingPanelRef.current = null;
          isNavigatingProgrammatically.current = false;
        }
      } else {
        // No pending panel but navigating programmatically - might be browser navigation
        // Reset flag and let normal URL sync handle it
        isNavigatingProgrammatically.current = false;
      }
      // Only return early if we still have the flag set AND we've handled the pending panel
      if (isNavigatingProgrammatically.current && !pendingPanelRef.current) {
        return;
      }
    }

    // Browser navigation (back/forward) or direct URL access
    // Clear any pending panel since this is not programmatic navigation
    if (pendingPanelRef.current) {
      pendingPanelRef.current = null;
    }

    lastPathnameRef.current = pathname;
    isUpdatingFromUrl.current = true;

    // Clear any existing transition timeout
    if (transitionTimeoutRef.current) {
      clearTimeout(transitionTimeoutRef.current);
    }

    // Parse URL to determine panel - no loading transition needed
    // New route structure: /home, /messages, /management, /queues/{dashboard|ongoing|failed|completed}
    // Use functional updates to avoid stale closure issues
    if (pathname === '/home') {
      setCurrentPanel(prev => {
        if (prev !== 'welcome') return 'welcome';
        return prev;
      });
      // Clear queue selection when on home
      setSelectedQueueId(prev => {
        if (prev !== null) return null;
        return prev;
      });
    } else if (pathname === '/messages') {
      setCurrentPanel(prev => {
        if (prev !== 'messages') return 'messages';
        return prev;
      });
      // Clear queue selection
      setSelectedQueueId(prev => {
        if (prev !== null) return null;
        return prev;
      });
    } else if (pathname === '/management') {
      setCurrentPanel(prev => {
        if (prev !== 'management') return 'management';
        return prev;
      });
      // Clear queue selection
      setSelectedQueueId(prev => {
        if (prev !== null) return null;
        return prev;
      });
    } else if (pathname.startsWith('/queues/')) {
      // Queue routes: /queues/dashboard, /queues/ongoing, /queues/failed, /queues/completed
      const match = pathname.match(/^\/queues\/(dashboard|ongoing|failed|completed)$/);
      if (match) {
        const subPanel = match[1];
        let targetPanel: 'welcome' | 'ongoing' | 'failed' | 'completed' = 'welcome';
        if (subPanel === 'dashboard') {
          targetPanel = 'welcome';
        } else if (subPanel === 'ongoing') {
          targetPanel = 'ongoing';
        } else if (subPanel === 'failed') {
          targetPanel = 'failed';
        } else if (subPanel === 'completed') {
          targetPanel = 'completed';
        }

        // Queue routes require a selected queue - restore from localStorage if needed
        // Use functional update to ensure we get the latest state
        setSelectedQueueId(prev => {
          if (!prev) {
            const stored = localStorage.getItem('selectedQueueId');
            if (stored) {
              return stored;
            }
          }
          return prev;
        });

        // ALWAYS set the panel to match the URL - don't check if it's already set
        // This ensures URL and panel state are always in sync
        setCurrentPanel(targetPanel);
      } else {
        // Invalid queue route - redirect to dashboard
        router.replace('/queues/dashboard');
      }
    }

    // Reset flag after URL sync completes
    transitionTimeoutRef.current = setTimeout(() => {
      isUpdatingFromUrl.current = false;
    }, 50);

    return () => {
      if (transitionTimeoutRef.current) {
        clearTimeout(transitionTimeoutRef.current);
      }
    };
  }, [pathname, selectedQueueId, getPathForPanel]); // Only depend on pathname to prevent loops

  const addToast = useCallback((message: string, type: 'success' | 'error' | 'info' | 'warning', debugData?: Record<string, any>) => {
    setToasts((prev) => {
      const now = Date.now();

      // Aggressive deduplication with message similarity check for toast aggregation
      // This prevents toast spam by grouping similar errors (e.g., multiple PendingQR)
      const normalizeMessage = (msg: string) => msg.toLowerCase().trim().replace(/\s+/g, ' ');
      const normalizedMessage = normalizeMessage(message);

      // Check for exact duplicates within 1 second
      const recentExactDuplicate = prev.find(
        (t) => t.message === message && t.type === type &&
          (now - parseInt(t.id.split('-')[0])) < 1000
      );

      if (recentExactDuplicate) {
        return prev; // Toast already exists, don't add duplicate
      }

      // Check for similar messages within 3 seconds (toast aggregation)
      // Group messages with similar content to prevent spam
      const recentSimilar = prev.find(
        (t) => {
          const timeDiff = now - parseInt(t.id.split('-')[0]);
          if (timeDiff > 3000) return false; // Only aggregate within 3 seconds
          if (t.type !== type) return false; // Must be same type

          const normalizedExisting = normalizeMessage(t.message);

          // Check for keyword overlap for common error patterns
          const commonErrorKeywords = [
            'واتساب', 'whatsapp', 'قر', 'qr', 'شبكة', 'network',
            'مصادقة', 'authentication', 'متصفح', 'browser', 'فشل', 'failed'
          ];

          const hasCommonKeyword = commonErrorKeywords.some(keyword =>
            normalizedMessage.includes(keyword) && normalizedExisting.includes(keyword)
          );

          // If messages share error keywords and are same type, aggregate them
          return hasCommonKeyword;
        }
      );

      if (recentSimilar) {
        // Similar toast exists, update its message to indicate multiple occurrences
        return prev.map(t => {
          if (t.id === recentSimilar.id) {
            // Check if already shows count
            const countMatch = t.message.match(/\((\d+)\s*\u0645\u0631\u0629\)$/); // matches "(N مرة)" in Arabic
            const currentCount = countMatch ? parseInt(countMatch[1]) : 1;
            const newCount = currentCount + 1;

            // Update message to show count
            const baseMessage = countMatch
              ? t.message.replace(/\(\d+\s*\u0645\u0631\u0629\)$/, '')
              : t.message;

            return {
              ...t,
              message: `${baseMessage.trim()} (${newCount} \u0645\u0631\u0629)`,
              debugData: debugData || t.debugData
            };
          }
          return t;
        });
      }

      const id = `${now}-${++toastCounterRef.current}`;
      const toast: Toast = { id, message, type, debugData };

      // Auto-remove toast after 3 seconds
      setTimeout(() => {
        setToasts((current) => current.filter((t) => t.id !== id));
      }, 3000);

      return [...prev, toast];
    });
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Enhanced setCurrentPanel that updates URL
  const handleSetCurrentPanel = useCallback((panel: 'messages' | 'management' | 'welcome' | 'ongoing' | 'failed' | 'completed') => {
    // Authentication check for management panel
    if (panel === 'management') {
      const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
      if (!token) {
        // Don't allow navigation to management without authentication
        return;
      }
    }

    // Panels that don't require a queue - clear queue selection first
    // Note: 'welcome' panel represents queue dashboard, so it DOES require a queue
    const panelsWithoutQueue = ['messages', 'management'];
    const shouldClearQueue = panelsWithoutQueue.includes(panel) && selectedQueueId !== null;

    // Calculate target path
    const targetPath = getPathForPanel(panel);

    // Prevent updates only if both panel state AND URL are already at target AND queue state is correct
    // This ensures URL always stays in sync with panel state
    if (currentPanel === panel && pathname === targetPath && !shouldClearQueue) {
      return;
    }

    // Clear any existing transition timeout
    if (transitionTimeoutRef.current) {
      clearTimeout(transitionTimeoutRef.current);
    }
    if (navigationTimeoutRef.current) {
      clearTimeout(navigationTimeoutRef.current);
    }

    // Mark that we're about to navigate - prevent URL sync effect from running
    lastPathnameRef.current = pathname; // Keep current pathname to prevent immediate sync
    isUpdatingFromUrl.current = true;
    isNavigatingProgrammatically.current = true;

    // Show loading during navigation - this prevents panel from rendering before URL is ready
    setIsTransitioning(true);

    // Store pending panel - will be activated when URL matches
    pendingPanelRef.current = panel;

    // Clear queue selection if needed (for panels that don't use queues)
    if (shouldClearQueue) {
      setSelectedQueueId(prev => {
        if (prev !== null) return null;
        return prev;
      });
    }

    // Navigate to target path FIRST - don't update panel state yet
    if (pathname !== targetPath) {
      router.push(targetPath);
    } else {
      // URL already matches - activate panel immediately
      setCurrentPanel(panel);
      pendingPanelRef.current = null;
      setIsTransitioning(false);
      isNavigatingProgrammatically.current = false;
      isUpdatingFromUrl.current = false;
    }

    // Fallback timeout - if URL doesn't update within 1 second, activate panel anyway
    navigationTimeoutRef.current = setTimeout(() => {
      if (pendingPanelRef.current === panel) {
        setCurrentPanel(panel);
        pendingPanelRef.current = null;
        setIsTransitioning(false);
        isNavigatingProgrammatically.current = false;
        isUpdatingFromUrl.current = false;
      }
    }, 1000);

    // Reset flags after URL sync completes (handled by URL sync effect)
  }, [router, selectedQueueId, currentPanel, pathname, getPathForPanel]);

  // Enhanced setSelectedQueueId that updates URL
  const handleSetSelectedQueueId = useCallback((id: string | null) => {
    // Calculate target path based on current panel and new queue selection
    let targetPath = '/home';
    let targetPanel: 'messages' | 'management' | 'welcome' | 'ongoing' | 'failed' | 'completed' = currentPanel;

    if (id !== null) {
      // Queue selected - always navigate to dashboard when clicking a queue
      // This provides consistent behavior: clicking a queue always shows its dashboard
      targetPath = '/queues/dashboard';
      targetPanel = 'welcome';
    } else {
      // No queue selected - go to home
      targetPath = '/home';
      targetPanel = 'welcome';
    }

    // Prevent updates only if both state AND URL are already at target
    // This prevents unnecessary navigation when clicking the same queue that's already selected
    if (selectedQueueId === id && pathname === targetPath) {
      return;
    }

    // Clear any existing transition timeout
    if (transitionTimeoutRef.current) {
      clearTimeout(transitionTimeoutRef.current);
    }
    if (navigationTimeoutRef.current) {
      clearTimeout(navigationTimeoutRef.current);
    }

    // Mark that we're about to navigate - prevent URL sync effect from running
    lastPathnameRef.current = pathname; // Keep current pathname to prevent immediate sync
    isUpdatingFromUrl.current = true;
    isNavigatingProgrammatically.current = true;

    // Show loading during queue selection navigation
    setIsTransitioning(true);

    // Store pending panel - will be activated when URL matches
    pendingPanelRef.current = targetPanel;

    // Update queue selection state immediately
    if (selectedQueueId !== id) {
      setSelectedQueueId(id);
    }

    // Navigate to target path FIRST - don't update panel state yet
    if (pathname !== targetPath) {
      router.push(targetPath);
    } else {
      // URL already matches - activate panel immediately
      setCurrentPanel(targetPanel);
      pendingPanelRef.current = null;
      setIsTransitioning(false);
      isNavigatingProgrammatically.current = false;
      isUpdatingFromUrl.current = false;
    }

    // Fallback timeout - if URL doesn't update within 1 second, activate panel anyway
    navigationTimeoutRef.current = setTimeout(() => {
      if (pendingPanelRef.current === targetPanel) {
        setCurrentPanel(targetPanel);
        pendingPanelRef.current = null;
        setIsTransitioning(false);
        isNavigatingProgrammatically.current = false;
        isUpdatingFromUrl.current = false;
      }
    }, 1000);
  }, [router, selectedQueueId, pathname, currentPanel, getPathForPanel]);

  // Cleanup transition timeout on unmount
  useEffect(() => {
    return () => {
      if (transitionTimeoutRef.current) {
        clearTimeout(transitionTimeoutRef.current);
      }
      if (navigationTimeoutRef.current) {
        clearTimeout(navigationTimeoutRef.current);
      }
    };
  }, []);

  return (
    <UIContext.Provider
      value={{
        toasts,
        addToast,
        removeToast,
        currentPanel,
        setCurrentPanel: handleSetCurrentPanel,
        selectedQueueId,
        setSelectedQueueId: handleSetSelectedQueueId,
        isTransitioning,
      }}
    >
      {children}
    </UIContext.Provider>
  );
};

export const useUI = () => {
  const context = useContext(UIContext);
  if (!context) {
    throw new Error('useUI must be used within UIProvider');
  }
  return context;
};
