namespace Clinics.Api.DTOs
{
    public class ResetPasswordDTO
    {
        public required string Password { get; set; }
    }
}
