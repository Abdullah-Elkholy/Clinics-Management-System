using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Clinics.Domain
{
    [Table("Users")]
    public class User : ISoftDeletable
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Username { get; set; } = null!;

        [StringLength(100)]
        public string? PasswordHash { get; set; }

        [Required]
        [StringLength(100)]
        public string FirstName { get; set; } = null!;

        [StringLength(100)]
        public string? LastName { get; set; }

        [Required]
        [StringLength(50)]
        public string Role { get; set; } = "user"; // Stores: primary_admin, secondary_admin, moderator, user

        /// <summary>
        /// For 'user' role: References the moderator who supervises this user.
        /// Users share their moderator's quota, queues, WhatsApp session, and all data.
        /// For moderator/admin roles: This should be null.
        /// </summary>
        public int? ModeratorId { get; set; }

        [ForeignKey(nameof(ModeratorId))]
        public User? Moderator { get; set; }

        /// <summary>
        /// For moderator/admin roles: Collection of users managed by this moderator.
        /// </summary>
        public ICollection<User> ManagedUsers { get; set; } = new List<User>();

        // Expose enum representation for server-side logic
        [NotMapped]
        public UserRole RoleEnum => UserRoleExtensions.FromRoleName(Role);

        // Computed FullName for backward compatibility
        [NotMapped]
        public string FullName
        {
            get => string.IsNullOrWhiteSpace(LastName) ? FirstName : $"{FirstName} {LastName}";
            set
            {
                // Parse fullName to firstName and lastName
                var parts = value.Split(' ', System.StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length > 0)
                {
                    FirstName = parts[0];
                    LastName = parts.Length > 1 ? string.Join(" ", parts.Skip(1)) : null;
                }
            }
        }

        // Audit fields
        [Required]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime? UpdatedAt { get; set; }

        public int? UpdatedBy { get; set; }

        /// <summary>
        /// Last successful login timestamp
        /// </summary>
        public DateTime? LastLogin { get; set; }

        // Soft-delete fields
        [Required]
        public bool IsDeleted { get; set; } = false;

        public DateTime? DeletedAt { get; set; }

        public int? DeletedBy { get; set; }

        // Restore fields
        public DateTime? RestoredAt { get; set; }

        public int? RestoredBy { get; set; }
    }

    [Table("Queues")]
    public class Queue : ISoftDeletable
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string DoctorName { get; set; } = null!;

        [Required]
        public int CreatedBy { get; set; }

        /// <summary>
        /// The moderator who owns this queue.
        /// All users under this moderator can access and use this queue.
        /// </summary>
        [Required]
        public int ModeratorId { get; set; }

        [ForeignKey(nameof(ModeratorId))]
        public User? Moderator { get; set; }

        [Required]
        public int CurrentPosition { get; set; } = 1;

        [Required]
        public int EstimatedWaitMinutes { get; set; } = 15;

        // Audit fields
        [Required]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime? UpdatedAt { get; set; }

        public int? UpdatedBy { get; set; }

        // Soft-delete fields
        [Required]
        public bool IsDeleted { get; set; } = false;

        public DateTime? DeletedAt { get; set; }

        public int? DeletedBy { get; set; }

        // Restore fields
        public DateTime? RestoredAt { get; set; }

        public int? RestoredBy { get; set; }
    }

    [Table("Patients")]
    public class Patient : ISoftDeletable
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int QueueId { get; set; }

        [ForeignKey(nameof(QueueId))]
        public Queue? Queue { get; set; } // OnDelete: Restrict (handled in ApplicationDbContext)

        [Required]
        [StringLength(100)]
        public string FullName { get; set; } = null!;

        [Required]
        [StringLength(20)]
        [Phone]
        public string PhoneNumber { get; set; } = null!;

        // PhoneExtension removed: all numbers validated and stored as single E.164 phone number.

        /// <summary>
        /// Country code for the phone number (e.g., "+20", "+966")
        /// Stored separately for display and validation purposes
        /// </summary>
        [Required]
        [StringLength(10)]
        public string CountryCode { get; set; } = "+20";

        /// <summary>
        /// Indicates whether the phone number has been validated for WhatsApp.
        /// null = not checked yet, true = valid WhatsApp number, false = invalid WhatsApp number.
        /// Automatically reset to null when PhoneNumber or CountryCode changes.
        /// </summary>
        public bool? IsValidWhatsAppNumber { get; set; }

        [Required]
        public int Position { get; set; }

        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "waiting";

        // Audit fields
        [Required]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public int? CreatedBy { get; set; }

        public DateTime? UpdatedAt { get; set; }

        public int? UpdatedBy { get; set; }

        // Soft-delete fields
        [Required]
        public bool IsDeleted { get; set; } = false;

        public DateTime? DeletedAt { get; set; }

        public int? DeletedBy { get; set; }

        // Restore fields
        public DateTime? RestoredAt { get; set; }

        public int? RestoredBy { get; set; }

        /// <summary>
        /// DEF-013 FIX: Row version for optimistic concurrency control.
        /// Prevents race conditions when multiple users update the same patient's position.
        /// EF Core will automatically check this value and throw DbUpdateConcurrencyException if stale.
        /// </summary>
        [Timestamp]
        public byte[]? RowVersion { get; set; }
    }

    [Table("MessageTemplates")]
    public class MessageTemplate : ISoftDeletable
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Title { get; set; } = null!;

        [Required]
        [StringLength(2000)]
        public string Content { get; set; } = null!;

        [Required]
        public int CreatedBy { get; set; }

        /// <summary>
        /// The moderator who owns this message template.
        /// All queues under this moderator can use these templates.
        /// </summary>
        [Required]
        public int ModeratorId { get; set; }

        [ForeignKey(nameof(ModeratorId))]
        public User? Moderator { get; set; }

        /// <summary>
        /// Queue this template belongs to (one-to-many: Queue -> Templates).
        /// This makes templates per-queue instead of moderator-global.
        /// Where each queue can have its own templates.
        /// </summary>
        [Required]
        public int QueueId { get; set; }

        [ForeignKey(nameof(QueueId))]
        public Queue? Queue { get; set; } // OnDelete: Restrict (handled in ApplicationDbContext)

        [Required]
        public DateTime CreatedAt { get; set; }

        /// <summary>
        /// Timestamp when template was last updated (for UI display, optimistic locking).
        /// </summary>
        public DateTime? UpdatedAt { get; set; }

        /// <summary>
        /// Foreign key to the one-to-one condition (REQUIRED relationship at database level).
        /// Every MessageTemplate MUST have exactly one MessageCondition.
        /// 
        /// Database-level enforcement:
        /// - MessageConditionId is [Required] (non-nullable in database)
        /// - Unique index on MessageConditionId ensures exactly one condition per template
        /// - Foreign key with CASCADE delete (deleting template deletes condition)
        /// - ApplicationDbContext configures this as .IsRequired() with .OnDelete(DeleteBehavior.Cascade)
        /// </summary>
        [Required]
        public int MessageConditionId { get; set; }

        /// <summary>
        /// Navigation to one-to-one condition (REQUIRED relationship at database level).
        /// Every MessageTemplate MUST have exactly one MessageCondition.
        /// 
        /// Condition.Operator encodes template state:
        ///   - DEFAULT: This template is the queue default (selected when no active condition matches). Exactly one per queue enforced by filtered unique index.
        ///   - UNCONDITIONED: Template has no custom selection criteria ("بدون شرط"). Used for templates without specific rules.
        ///   - EQUAL/GREATER/LESS/RANGE: Active condition determining when this template is selected.
        /// </summary>
        [ForeignKey(nameof(MessageConditionId))]
        public MessageCondition? Condition { get; set; }

        // Audit fields (UpdatedBy already present; ensure it exists)
        public int? UpdatedBy { get; set; }

        // Soft-delete fields
        [Required]
        public bool IsDeleted { get; set; } = false;

        public DateTime? DeletedAt { get; set; }

        public int? DeletedBy { get; set; }

        // Restore fields
        public DateTime? RestoredAt { get; set; }

        public int? RestoredBy { get; set; }
    }

    [Table("Messages")]
    public class Message
    {
        /// <summary>
        /// Unique identifier for this message.
        /// Changed from long to Guid for better scalability and distribution.
        /// </summary>
        [Key]
        public Guid Id { get; set; }

        /// <summary>
        /// Patient's queue position at the time of message creation.
        /// Used to trace why this message is being sent.
        /// Source: Patient.Position
        /// </summary>
        [Required]
        public int Position { get; set; }

        /// <summary>
        /// Calculated position (offset from Current Queue Position).
        /// Calculated as: Patient.Position - Queue.CurrentPosition
        /// Used for message condition matching.
        /// </summary>
        [Required]
        public int CalculatedPosition { get; set; }

        /// <summary>
        /// Patient's full name at the time of message creation.
        /// Stored for traceability and display purposes.
        /// Source: Patient.FullName
        /// </summary>
        [Required]
        [StringLength(100)]
        public string FullName { get; set; } = null!;

        /// <summary>
        /// Country code for the phone number (e.g., "+20", "+966")
        /// Stored separately for display and validation purposes.
        /// Source: Patient.CountryCode
        /// </summary>
        [Required]
        [StringLength(10)]
        public string CountryCode { get; set; } = "+20";

        [Required]
        [StringLength(20)]
        [Phone]
        public string? PatientPhone { get; set; }

        /// <summary>
        /// Message content with resolved variables.
        /// Variables (e.g., {PN}, {CQP}, {ETR}) are resolved before saving.
        /// Stores the actual text sent to patient, not the template.
        /// </summary>
        [Required]
        [StringLength(2000)]
        public string Content { get; set; } = null!;

        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "queued";

        /// <summary>
        /// Error message in Arabic when message fails.
        /// NULL when Status = "sent" (successful delivery).
        /// Always populated in Arabic when there's an error.
        /// </summary>
        [StringLength(500)]
        public string? ErrorMessage { get; set; }

        public int? PatientId { get; set; }

        public int? TemplateId { get; set; }

        [ForeignKey(nameof(TemplateId))]
        public MessageTemplate? Template { get; set; }

        public int? QueueId { get; set; }

        [ForeignKey(nameof(QueueId))]
        public Queue? Queue { get; set; } // OnDelete: Restrict (handled in ApplicationDbContext)

        public int? SenderUserId { get; set; }

        /// <summary>
        /// The moderator associated with this message.
        /// Tracks quota consumption and session usage per moderator.
        /// </summary>
        public int? ModeratorId { get; set; }

        [ForeignKey(nameof(ModeratorId))]
        public User? Moderator { get; set; }

        /// <summary>
        /// Session identifier for grouping related messages.
        /// Messages sent together in a batch share the same SessionId.
        /// Links to MessageSession entity for unified session management per moderator.
        /// </summary>
        [StringLength(100)]
        public string? SessionId { get; set; }

        /// <summary>
        /// Correlation ID for tracing this message through distributed logs and retry flows.
        /// Propagated from MessageSession.CorrelationId for end-to-end tracking.
        /// </summary>
        public Guid? CorrelationId { get; set; }


        [Required]
        public int Attempts { get; set; }

        public DateTime? LastAttemptAt { get; set; }

        public DateTime? SentAt { get; set; }

        /// <summary>
        /// User who created this message (for audit)
        /// </summary>
        public int? CreatedBy { get; set; }

        [Required]
        public DateTime CreatedAt { get; set; }

        /// <summary>
        /// User who last updated this message (for audit)
        /// </summary>
        public int? UpdatedBy { get; set; }

        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

        /// <summary>
        /// Indicates if this message is paused and should not be processed.
        /// When true, MessageProcessor will skip this message.
        /// Lowest priority in pause hierarchy: WhatsAppSession → MessageSession → Message.
        /// </summary>
        [Required]
        public bool IsPaused { get; set; } = false;

        /// <summary>
        /// Timestamp when message was paused (for audit)
        /// </summary>
        public DateTime? PausedAt { get; set; }

        /// <summary>
        /// User who paused this message (for audit)
        /// </summary>
        public int? PausedBy { get; set; }

        /// <summary>
        /// Reason for pausing (e.g., "PendingQR", "UserPaused", "SessionPaused")
        /// </summary>
        [StringLength(100)]
        public string? PauseReason { get; set; }

        /// <summary>
        /// When this message becomes eligible for retry after a transient failure.
        /// Used for durable retry scheduling instead of in-memory Task.Run delays.
        /// Processor query includes: OR (NextAttemptAt IS NOT NULL AND NextAttemptAt <= NOW)
        /// </summary>
        public DateTime? NextAttemptAt { get; set; }

        /// <summary>
        /// ID of the extension command currently processing this message.
        /// Prevents creating duplicate commands when the provider times out but command is still running.
        /// Cleared when command completes (success or failure) or message returns to queued.
        /// </summary>
        public Guid? InFlightCommandId { get; set; }

        /// <summary>
        /// Concurrency token for optimistic concurrency control.
        /// Prevents lost updates when pause and send-complete race.
        /// </summary>
        [Timestamp]
        public byte[]? RowVersion { get; set; }

        // Soft-delete fields
        [Required]
        public bool IsDeleted { get; set; } = false;

        public DateTime? DeletedAt { get; set; }

        public int? DeletedBy { get; set; }
    }

    // FailedTask entity REMOVED: Failures now tracked via Message.Status = "failed"
    // Migration will drop FailedTasks table

    [Table("Quotas")]
    public class Quota
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int ModeratorUserId { get; set; }

        [ForeignKey(nameof(ModeratorUserId))]
        public User? Moderator { get; set; } // OnDelete: Restrict (handled in ApplicationDbContext)

        /// <summary>
        /// Messages quota limit. Use -1 for unlimited, or a positive number for a specific limit.
        /// Stored as bigint in database to support very large values.
        /// </summary>
        [Required]
        public long MessagesQuota { get; set; }

        /// <summary>
        /// Total messages consumed (accumulative, never resets).
        /// Stored as bigint in database to support very large values.
        /// </summary>
        [Required]
        public long ConsumedMessages { get; set; }

        [Required]
        public int QueuesQuota { get; set; }

        [Required]
        public int ConsumedQueues { get; set; }

        [Required]
        public DateTime UpdatedAt { get; set; }

        /// <summary>
        /// Remaining messages quota. Returns -1 if MessagesQuota is -1 (unlimited).
        /// Can be negative if consumed exceeds limit.
        /// </summary>
        [NotMapped]
        public long RemainingMessages => MessagesQuota == -1 ? -1 : MessagesQuota - ConsumedMessages;

        /// <summary>
        /// Remaining queues quota. Returns -1 if QueuesQuota is -1 (unlimited).
        /// Can be negative if consumed exceeds limit.
        /// </summary>
        [NotMapped]
        public long RemainingQueues => QueuesQuota == -1 ? -1 : QueuesQuota - ConsumedQueues;

        /// <summary>
        /// Check if quota is low (less than 10%). Returns false if quota is unlimited (-1).
        /// </summary>
        [NotMapped]
        public bool IsMessagesQuotaLow => MessagesQuota != -1 && MessagesQuota > 0 && (RemainingMessages * 100.0 / MessagesQuota) < 10;

        /// <summary>
        /// Check if queues quota is low (less than 10%). Returns false if quota is unlimited (-1).
        /// </summary>
        [NotMapped]
        public bool IsQueuesQuotaLow => QueuesQuota != -1 && QueuesQuota > 0 && (RemainingQueues * 100.0 / QueuesQuota) < 10;

        // Audit fields
        [Required]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public int? CreatedBy { get; set; }

        public int? UpdatedBy { get; set; }

        // Soft-delete fields
        [Required]
        public bool IsDeleted { get; set; } = false;

        public DateTime? DeletedAt { get; set; }

        public int? DeletedBy { get; set; }

        // Restore fields
        public DateTime? RestoredAt { get; set; }

        public int? RestoredBy { get; set; }
    }


    [Table("Sessions")]
    public class Session
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        public int UserId { get; set; }

        [Required]
        [StringLength(100)]
        public string RefreshToken { get; set; } = null!;

        [Required]
        public DateTime ExpiresAt { get; set; }

        [Required]
        public DateTime CreatedAt { get; set; }

        [StringLength(50)]
        public string? IpAddress { get; set; }

        [StringLength(500)]
        public string? UserAgent { get; set; }
    }

    [Table("WhatsAppSessions")]
    public class WhatsAppSession : ISoftDeletable
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int ModeratorUserId { get; set; }

        // SessionName, ProviderSessionId, LastSyncAt REMOVED - deprecated columns

        [StringLength(20)]
        public string? Status { get; set; }

        [Required]
        public DateTime CreatedAt { get; set; }

        // Audit trail fields
        public int? CreatedByUserId { get; set; }
        public int? LastActivityUserId { get; set; }
        public DateTime? LastActivityAt { get; set; }

        /// <summary>
        /// Global pause flag for all ongoing tasks for this moderator.
        /// When true, ALL messages, sessions, and operations for this moderator are paused.
        /// Highest priority in pause hierarchy: WhatsAppSession → MessageSession → Message.
        /// </summary>
        [Required]
        public bool IsPaused { get; set; } = false;

        /// <summary>
        /// Timestamp when global pause was activated (for audit)
        /// </summary>
        public DateTime? PausedAt { get; set; }

        /// <summary>
        /// User who activated global pause (for audit)
        /// </summary>
        public int? PausedBy { get; set; }

        /// <summary>
        /// Reason for global pause (e.g., "PendingQR", "PendingNET", "BrowserClosed", "Authentication check", "CheckWhatsApp")
        /// Max 100 characters for database efficiency
        /// </summary>
        [StringLength(100)]
        public string? PauseReason { get; set; }

        /// <summary>
        /// Computed property indicating whether the session can be resumed.
        /// CRITICAL: A paused session is ONLY resumable when:
        /// - It is paused AND
        /// - Session Status is "connected" (authenticated and working) AND
        /// - PauseReason is NOT "CheckWhatsApp" (checks must complete before resuming)
        /// This ensures users cannot resume when session is pending/disconnected or during check operations,
        /// preventing message sending failures and providing clear feedback.
        /// </summary>
        [System.ComponentModel.DataAnnotations.Schema.NotMapped]
        public bool IsResumable => IsPaused
            && Status == "connected"
            && PauseReason?.Contains("CheckWhatsApp", StringComparison.OrdinalIgnoreCase) != true;

        // Soft-delete fields
        public bool IsDeleted { get; set; } = false;
        public DateTime? DeletedAt { get; set; }
        public int? DeletedBy { get; set; }
        public DateTime? RestoredAt { get; set; }
        public int? RestoredBy { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public int? UpdatedBy { get; set; }
    }

    [Table("MessageSessions")]
    public class MessageSession
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        public int QueueId { get; set; }

        [ForeignKey(nameof(QueueId))]
        public Queue? Queue { get; set; } // OnDelete: Restrict (handled in ApplicationDbContext)

        /// <summary>
        /// The moderator who owns this session.
        /// All users under this moderator share the same WhatsApp session.
        /// </summary>
        [Required]
        public int ModeratorId { get; set; }

        [ForeignKey(nameof(ModeratorId))]
        public User? Moderator { get; set; }

        [Required]
        public int UserId { get; set; }

        /// <summary>
        /// Type of session: "send" for message sending, "check_whatsapp" for number validation.
        /// Check sessions have higher priority and don't appear in CompletedTasksPanel.
        /// </summary>
        [Required]
        [StringLength(20)]
        public string SessionType { get; set; } = MessageSessionTypes.Send;

        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "active"; // active, paused, completed, cancelled

        /// <summary>
        /// Indicates if this session is paused.
        /// When true, all messages in this session are paused.
        /// </summary>
        [Required]
        public bool IsPaused { get; set; } = false;

        [Required]
        public int TotalMessages { get; set; }

        [Required]
        public int SentMessages { get; set; }

        /// <summary>
        /// Number of messages in this session that have failed.
        /// Auto-updated when Message.Status changes to "failed".
        /// Used for FailedTasksPanel filtering.
        /// </summary>
        [Required]
        public int FailedMessages { get; set; } = 0;

        /// <summary>
        /// Number of messages in this session that are ongoing (queued or sending).
        /// Auto-updated when Message.Status is "queued" or "sending".
        /// Used for OngoingTasksPanel filtering.
        /// </summary>
        [Required]
        public int OngoingMessages { get; set; } = 0;

        [Required]
        public DateTime StartTime { get; set; }

        public DateTime? EndTime { get; set; }

        public DateTime? LastUpdated { get; set; }

        /// <summary>
        /// Timestamp when session was paused (for audit)
        /// </summary>
        public DateTime? PausedAt { get; set; }

        /// <summary>
        /// User who paused this session (for audit)
        /// </summary>
        public int? PausedBy { get; set; }

        /// <summary>
        /// Reason for pausing (e.g., "PendingQR", "UserPaused")
        /// </summary>
        [StringLength(100)]
        public string? PauseReason { get; set; }

        /// <summary>
        /// Correlation ID for tracking this session through logs and retry flows
        /// </summary>
        public Guid? CorrelationId { get; set; }

        /// <summary>
        /// Concurrency token for optimistic concurrency control.
        /// Prevents lost updates when multiple operations modify session state.
        /// </summary>
        [Timestamp]
        public byte[]? RowVersion { get; set; }

        // Soft-delete fields
        [Required]
        public bool IsDeleted { get; set; } = false;

        public DateTime? DeletedAt { get; set; }

        public int? DeletedBy { get; set; }
    }

    // ModeratorSettings entity REMOVED: No longer used
    // WhatsApp phone number tracked via WhatsAppSession
    // Migration will drop ModeratorSettings table

    /// <summary>
    /// MessageCondition: One-to-one REQUIRED relationship with MessageTemplate.
    /// Represents condition criteria for template selection during message sending.
    /// 
    /// Relationship:
    /// - The relationship is owned by MessageTemplate (MessageTemplate has MessageConditionId foreign key)
    /// - Every MessageCondition MUST belong to exactly one MessageTemplate
    /// - Every MessageTemplate MUST have exactly one MessageCondition
    /// 
    /// Validation:
    /// - Unique index on MessageTemplate.MessageConditionId (one condition per template)
    /// - QueueId is required (each condition belongs to a specific queue)
    /// - Operator must be one of: DEFAULT, UNCONDITIONED, EQUAL, GREATER, LESS, RANGE
    /// - Value required for EQUAL/GREATER/LESS; MinValue and MaxValue required for RANGE
    /// - DEFAULT operator: Exactly one per queue (enforced by filtered unique index)
    /// </summary>
    [Table("MessageConditions")]
    public class MessageCondition : ISoftDeletable
    {
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// Foreign key to the one-to-one REQUIRED relationship with MessageTemplate.
        /// This facilitates finding template from condition without loading navigation property.
        /// Every MessageCondition MUST belong to exactly one MessageTemplate.
        /// 
        /// Note: The relationship is owned by MessageTemplate (MessageTemplate.MessageConditionId -> MessageCondition.Id),
        /// but this foreign key provides reverse lookup capability for easier queries.
        /// </summary>
        public int? TemplateId { get; set; }

        /// <summary>
        /// Navigation property to the one-to-one REQUIRED relationship with MessageTemplate.
        /// 
        /// The relationship is now owned by MessageTemplate (MessageTemplate has MessageConditionId foreign key).
        /// Every MessageCondition MUST belong to exactly one MessageTemplate.
        /// 
        /// The Operator encodes the semantic state of the template:
        ///   - DEFAULT: This template is the queue default (fallback when no active condition matches).
        ///              Exactly one per queue enforced by filtered unique index: WHERE Operator = 'DEFAULT'.
        ///   - UNCONDITIONED: No custom criteria; template selection is unconditioned ("بدون شرط").
        ///   - EQUAL/GREATER/LESS/RANGE: Active condition; template selected when patient field matches operator/values.
        /// 
        /// Note: [ForeignKey] attribute removed. Relationship is fully configured via Fluent API in ApplicationDbContext
        /// to avoid EF Core warning about dual ForeignKey attributes creating two separate relationships.
        /// </summary>
        public MessageTemplate? Template { get; set; }

        /// <summary>
        /// Queue this condition belongs to.
        /// Each queue can have multiple conditions (one per template).
        /// </summary>
        [Required]
        public int QueueId { get; set; }

        [ForeignKey(nameof(QueueId))]
        public Queue? Queue { get; set; } // OnDelete: Restrict (handled in ApplicationDbContext)

        /// <summary>
        /// Operator encodes template state and selection logic:
        ///   - UNCONDITIONED: No values required (all numeric fields null); template has no selection criteria.
        ///   - DEFAULT: No values required; this is queue default (fallback). Unique per queue.
        ///   - EQUAL: Single value required; send when field == Value.
        ///   - GREATER: Single value required; send when field > Value.
        ///   - LESS: Single value required; send when field < Value.
        ///   - RANGE: MinValue and MaxValue required; send when MinValue <= field <= MaxValue.
        /// </summary>
        [Required]
        [StringLength(20)]
        public string Operator { get; set; } = "UNCONDITIONED";

        /// <summary>
        /// For EQUAL, GREATER, LESS: single comparison value.
        /// Example: EQUAL with Value=42 means "send when field = 42"
        /// Must be null for UNCONDITIONED, DEFAULT, or RANGE.
        /// </summary>
        public int? Value { get; set; }

        /// <summary>
        /// For RANGE: minimum boundary (inclusive).
        /// Example: MinValue=10 with MaxValue=20 means "send when 10 <= field <= 20"
        /// Must be null for UNCONDITIONED, DEFAULT, EQUAL, GREATER, LESS.
        /// </summary>
        public int? MinValue { get; set; }

        /// <summary>
        /// For RANGE: maximum boundary (inclusive).
        /// Constraint: MinValue <= MaxValue must be enforced at service level.
        /// Must be null for UNCONDITIONED, DEFAULT, EQUAL, GREATER, LESS.
        /// </summary>
        public int? MaxValue { get; set; }

        [Required]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        /// <summary>
        /// Timestamp of last update (for UI, tracking changes).
        /// </summary>
        public DateTime? UpdatedAt { get; set; }

        // Audit fields
        public int? CreatedBy { get; set; }

        public int? UpdatedBy { get; set; }

        // Soft-delete fields
        [Required]
        public bool IsDeleted { get; set; } = false;

        public DateTime? DeletedAt { get; set; }

        public int? DeletedBy { get; set; }

        // Restore fields
        public DateTime? RestoredAt { get; set; }

        public int? RestoredBy { get; set; }
    }

    // AuditLog entity REMOVED: No longer used
    // Migration will drop AuditLogs table

    #region Extension Runner Entities

    /// <summary>
    /// Represents a paired browser extension device for a moderator.
    /// Each moderator can have multiple paired devices, but only one active lease at a time.
    /// </summary>
    [Table("ExtensionDevices")]
    public class ExtensionDevice
    {
        [Key]
        public Guid Id { get; set; }

        /// <summary>
        /// The moderator this device is paired with.
        /// </summary>
        [Required]
        public int ModeratorUserId { get; set; }

        [ForeignKey(nameof(ModeratorUserId))]
        public User? Moderator { get; set; }

        /// <summary>
        /// Unique device identifier generated and stored by the extension.
        /// Used to identify the same extension instance across sessions.
        /// </summary>
        [Required]
        [StringLength(64)]
        public string DeviceId { get; set; } = null!;

        /// <summary>
        /// Friendly name for the device (e.g., "Chrome on Desktop", "Work Laptop").
        /// Set by user during pairing or auto-generated from user agent.
        /// </summary>
        [StringLength(100)]
        public string? DeviceName { get; set; }

        /// <summary>
        /// Hash of the device token (never store plain token).
        /// Token is issued during pairing and used for authentication.
        /// </summary>
        [Required]
        [StringLength(128)]
        public string TokenHash { get; set; } = null!;

        /// <summary>
        /// Extension version at time of pairing (e.g., "1.0.0").
        /// </summary>
        [StringLength(20)]
        public string? ExtensionVersion { get; set; }

        /// <summary>
        /// Browser user agent at time of pairing.
        /// </summary>
        [StringLength(500)]
        public string? UserAgent { get; set; }

        /// <summary>
        /// When the device token expires and requires re-pairing.
        /// </summary>
        [Required]
        public DateTime TokenExpiresAtUtc { get; set; }

        /// <summary>
        /// When this device was first paired.
        /// </summary>
        [Required]
        public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;

        /// <summary>
        /// Last time this device was seen (heartbeat or command completion).
        /// </summary>
        public DateTime? LastSeenAtUtc { get; set; }

        /// <summary>
        /// If device is revoked, this is when it was revoked.
        /// </summary>
        public DateTime? RevokedAtUtc { get; set; }

        /// <summary>
        /// Reason for revocation (e.g., "UserRevoked", "AdminRevoked", "TokenExpired", "Takeover").
        /// </summary>
        [StringLength(50)]
        public string? RevokedReason { get; set; }

        /// <summary>
        /// Whether this device is currently active (not revoked).
        /// </summary>
        [NotMapped]
        public bool IsActive => RevokedAtUtc == null && TokenExpiresAtUtc > DateTime.UtcNow;

        /// <summary>
        /// The pairing code that was used to pair this device (optional, one-to-one).
        /// Reverse navigation from ExtensionPairingCode.UsedByDevice.
        /// </summary>
        public ExtensionPairingCode? PairingCode { get; set; }
    }

    /// <summary>
    /// Represents a pairing code for connecting an extension to a moderator account.
    /// Short-lived (5 minutes) and single-use.
    /// </summary>
    [Table("ExtensionPairingCodes")]
    public class ExtensionPairingCode
    {
        [Key]
        public Guid Id { get; set; }

        /// <summary>
        /// The moderator requesting to pair a device.
        /// </summary>
        [Required]
        public int ModeratorUserId { get; set; }

        [ForeignKey(nameof(ModeratorUserId))]
        public User? Moderator { get; set; }

        /// <summary>
        /// Short numeric code for user to enter in extension (e.g., "12345678").
        /// </summary>
        [Required]
        [StringLength(8)]
        public string Code { get; set; } = null!;

        /// <summary>
        /// When this code was created.
        /// </summary>
        [Required]
        public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;

        /// <summary>
        /// When this code expires (typically 5 minutes after creation).
        /// </summary>
        [Required]
        public DateTime ExpiresAtUtc { get; set; }

        /// <summary>
        /// When this code was used (null if not yet used).
        /// </summary>
        public DateTime? UsedAtUtc { get; set; }

        /// <summary>
        /// The device that used this code (null if not yet used).
        /// </summary>
        public Guid? UsedByDeviceId { get; set; }

        [ForeignKey(nameof(UsedByDeviceId))]
        public ExtensionDevice? UsedByDevice { get; set; }

        /// <summary>
        /// Whether this code is still valid (not expired, not used).
        /// </summary>
        [NotMapped]
        public bool IsValid => UsedAtUtc == null && ExpiresAtUtc > DateTime.UtcNow;
    }

    /// <summary>
    /// Represents an active session lease for a browser extension.
    /// Only one active lease per moderator at a time (enforced by unique index).
    /// Lease must be renewed via heartbeat or it expires.
    /// </summary>
    [Table("ExtensionSessionLeases")]
    public class ExtensionSessionLease
    {
        [Key]
        public Guid Id { get; set; }

        /// <summary>
        /// The moderator this lease is for.
        /// Unique constraint ensures only one active lease per moderator.
        /// </summary>
        [Required]
        public int ModeratorUserId { get; set; }

        [ForeignKey(nameof(ModeratorUserId))]
        public User? Moderator { get; set; }

        /// <summary>
        /// The device holding this lease.
        /// </summary>
        [Required]
        public Guid DeviceId { get; set; }

        [ForeignKey(nameof(DeviceId))]
        public ExtensionDevice? Device { get; set; }

        /// <summary>
        /// Hash of lease token for validation.
        /// </summary>
        [Required]
        [StringLength(128)]
        public string LeaseTokenHash { get; set; } = null!;

        /// <summary>
        /// When this lease was acquired.
        /// </summary>
        [Required]
        public DateTime AcquiredAtUtc { get; set; } = DateTime.UtcNow;

        /// <summary>
        /// When this lease expires if not renewed.
        /// Typically 2-5 minutes from last heartbeat.
        /// </summary>
        [Required]
        public DateTime ExpiresAtUtc { get; set; }

        /// <summary>
        /// Last heartbeat received from the extension.
        /// </summary>
        [Required]
        public DateTime LastHeartbeatAtUtc { get; set; }

        /// <summary>
        /// If lease was revoked (takeover or explicit release), when it was revoked.
        /// </summary>
        public DateTime? RevokedAtUtc { get; set; }

        /// <summary>
        /// Reason for revocation (e.g., "Released", "Takeover", "Expired", "AdminRevoked").
        /// </summary>
        [StringLength(50)]
        public string? RevokedReason { get; set; }

        /// <summary>
        /// Current WhatsApp Web tab URL as reported by extension.
        /// </summary>
        [StringLength(500)]
        public string? CurrentUrl { get; set; }

        /// <summary>
        /// Current WhatsApp session status as reported by extension.
        /// Values: "connected", "pending_qr", "pending_net", "disconnected", "unknown"
        /// </summary>
        [StringLength(20)]
        public string? WhatsAppStatus { get; set; }

        /// <summary>
        /// Last error message from extension (for diagnostics).
        /// </summary>
        [StringLength(500)]
        public string? LastError { get; set; }

        /// <summary>
        /// Whether this lease is currently active (not revoked, not expired).
        /// </summary>
        [NotMapped]
        public bool IsActive => RevokedAtUtc == null && ExpiresAtUtc > DateTime.UtcNow;
    }

    /// <summary>
    /// Represents a command sent to the browser extension.
    /// Commands are processed in order and must be acknowledged.
    /// </summary>
    [Table("ExtensionCommands")]
    public class ExtensionCommand
    {
        [Key]
        public Guid Id { get; set; }

        /// <summary>
        /// The moderator/extension this command is for.
        /// </summary>
        [Required]
        public int ModeratorUserId { get; set; }

        [ForeignKey(nameof(ModeratorUserId))]
        public User? Moderator { get; set; }

        /// <summary>
        /// Command type (e.g., "SendMessage", "Refresh", "HealthCheck", "Pause").
        /// </summary>
        [Required]
        [StringLength(50)]
        public string CommandType { get; set; } = null!;

        /// <summary>
        /// JSON payload with command-specific data.
        /// For SendMessage: { phoneNumber, messageText, messageId, sessionId }
        /// </summary>
        [Required]
        [Column(TypeName = "nvarchar(max)")]
        public string PayloadJson { get; set; } = null!;

        /// <summary>
        /// Reference to the Message entity if this is a SendMessage command.
        /// </summary>
        public Guid? MessageId { get; set; }

        [ForeignKey(nameof(MessageId))]
        public Message? Message { get; set; }

        /// <summary>
        /// Command status: "pending", "sent", "acked", "completed", "failed", "expired"
        /// </summary>
        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "pending";

        /// <summary>
        /// When this command was created.
        /// </summary>
        [Required]
        public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;

        /// <summary>
        /// When this command expires and should be considered failed.
        /// </summary>
        [Required]
        public DateTime ExpiresAtUtc { get; set; }

        /// <summary>
        /// When command was sent to extension via SignalR/SSE.
        /// </summary>
        public DateTime? SentAtUtc { get; set; }

        /// <summary>
        /// When extension acknowledged receipt of command.
        /// </summary>
        public DateTime? AckedAtUtc { get; set; }

        /// <summary>
        /// When extension reported completion (success or failure).
        /// </summary>
        public DateTime? CompletedAtUtc { get; set; }

        /// <summary>
        /// JSON result from extension.
        /// Contains status, error details, observations, etc.
        /// </summary>
        [Column(TypeName = "nvarchar(max)")]
        public string? ResultJson { get; set; }

        /// <summary>
        /// Result status from extension (e.g., "success", "pendingQR", "pendingNET", "failed").
        /// </summary>
        [StringLength(20)]
        public string? ResultStatus { get; set; }

        /// <summary>
        /// Number of times this command was retried.
        /// </summary>
        [Required]
        public int RetryCount { get; set; } = 0;

        /// <summary>
        /// Priority for command ordering (lower = higher priority).
        /// Default 100, urgent commands can use lower values.
        /// </summary>
        [Required]
        public int Priority { get; set; } = 100;
    }

    /// <summary>
    /// Message session types for distinguishing send vs check operations.
    /// </summary>
    public static class MessageSessionTypes
    {
        public const string Send = "send";
        public const string CheckWhatsApp = "check_whatsapp";
    }

    /// <summary>
    /// Enum for extension command types.
    /// </summary>
    public static class ExtensionCommandTypes
    {
        public const string SendMessage = "SendMessage";
        public const string CheckWhatsAppNumber = "CheckWhatsAppNumber";
        public const string Refresh = "Refresh";
        public const string HealthCheck = "HealthCheck";
        public const string Pause = "Pause";
        public const string Resume = "Resume";
        public const string GetStatus = "GetStatus";
        public const string GetQrCode = "GetQrCode";
    }

    /// <summary>
    /// Enum for extension command statuses.
    /// </summary>
    public static class ExtensionCommandStatuses
    {
        public const string Pending = "pending";
        public const string Sent = "sent";
        public const string Acked = "acked";
        public const string Completed = "completed";
        public const string Failed = "failed";
        public const string Expired = "expired";
    }

    /// <summary>
    /// Enum for extension result statuses (from extension to server).
    /// Maps to existing OperationResult categories.
    /// P2.9: Added ExtensionTimeout and NoActiveLease for explicit error handling.
    /// </summary>
    public static class ExtensionResultStatuses
    {
        public const string Success = "success";
        public const string PendingQR = "pendingQR";
        public const string PendingNET = "pendingNET";
        public const string Waiting = "waiting";
        public const string Failed = "failed";

        /// <summary>
        /// Extension command timed out but may still complete later.
        /// Message should stay in 'sending' state.
        /// </summary>
        public const string ExtensionTimeout = "extensionTimeout";

        /// <summary>
        /// No active extension lease for the moderator.
        /// User needs to connect the browser extension.
        /// </summary>
        public const string NoActiveLease = "noActiveLease";
    }

    #endregion
    public class PhoneWhatsAppRegistry
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(20)]
        public string PhoneNumber { get; set; } = null!; // E.164 format

        public bool HasWhatsApp { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime? ExpiresAt { get; set; }

        public int? CheckedByUserId { get; set; }

        public int ValidationCount { get; set; }
    }

    /// <summary>
    /// System-wide configuration settings.
    /// Used for rate limiting, feature flags, and other admin-configurable options.
    /// </summary>
    [Table("SystemSettings")]
    public class SystemSettings
    {
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// Unique key for the setting (e.g., "RateLimitMinSeconds", "RateLimitMaxSeconds")
        /// </summary>
        [Required]
        [StringLength(50)]
        public string Key { get; set; } = null!;

        /// <summary>
        /// Setting value as string (parsed based on context)
        /// </summary>
        [Required]
        [StringLength(200)]
        public string Value { get; set; } = null!;

        /// <summary>
        /// Description in Arabic for admin UI
        /// </summary>
        [StringLength(500)]
        public string? Description { get; set; }

        /// <summary>
        /// Category for grouping settings (e.g., "RateLimit", "Features")
        /// </summary>
        [StringLength(50)]
        public string? Category { get; set; }

        // Audit fields
        [Required]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime? UpdatedAt { get; set; }

        public int? UpdatedBy { get; set; }
    }

    /// <summary>
    /// Well-known keys for system settings
    /// </summary>
    public static class SystemSettingKeys
    {
        public const string RateLimitMinSeconds = "RateLimitMinSeconds";
        public const string RateLimitMaxSeconds = "RateLimitMaxSeconds";
        public const string RateLimitEnabled = "RateLimitEnabled";
    }
}
